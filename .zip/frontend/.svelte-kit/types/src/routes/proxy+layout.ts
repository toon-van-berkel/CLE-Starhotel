// @ts-nocheck
import type { LayoutLoad } from './$types';
import { refreshMe } from '$lib/api/auth/sessions';

export const ssr = false;
export const prerender = false;

export const load = async ({ fetch }: Parameters<LayoutLoad>[0]) => {
	const user = await refreshMe(fetch);
	return { user };
};
