// @ts-nocheck
import type { LayoutServerLoad } from './$types';
import { requireRole } from '$lib/api/auth/guards';

export const load = async ({ fetch }: Parameters<LayoutServerLoad>[0]) => {
	await requireRole(fetch, 1);
	return {};
};
