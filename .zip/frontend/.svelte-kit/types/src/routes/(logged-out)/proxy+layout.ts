// @ts-nocheck
import type { LayoutLoad } from './$types';
import { requireLoggedOut } from '$lib/api/auth/guards';

export const load = async ({ fetch }: Parameters<LayoutLoad>[0]) => {
	await requireLoggedOut(fetch);
	return {};
};
