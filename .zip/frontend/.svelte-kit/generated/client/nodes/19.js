import * as universal from "../../../../src/routes/test/rooms/[id]/+page.ts";
export { universal };
export { default as component } from "../../../../src/routes/test/rooms/[id]/+page.svelte";