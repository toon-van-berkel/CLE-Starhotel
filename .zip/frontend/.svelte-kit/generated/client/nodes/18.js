import * as universal from "../../../../src/routes/test/rooms/+page.ts";
export { universal };
export { default as component } from "../../../../src/routes/test/rooms/+page.svelte";