import * as universal from "../../../../src/routes/test/(auth)/+page.ts";
export { universal };
export { default as component } from "../../../../src/routes/test/(auth)/+page.svelte";