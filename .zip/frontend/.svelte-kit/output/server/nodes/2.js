

export const index = 2;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/2.DijLGZGC.js","_app/immutable/chunks/DsnmJJEf.js","_app/immutable/chunks/69_IOA4Y.js","_app/immutable/chunks/DIeogL5L.js","_app/immutable/chunks/CfgsdJGj.js","_app/immutable/chunks/BEX6EZJS.js","_app/immutable/chunks/mb3lfQoK.js","_app/immutable/chunks/Co-k0xhD.js","_app/immutable/chunks/BvR5KVtc.js","_app/immutable/chunks/DwzC-bs9.js","_app/immutable/chunks/VPrQAXsl.js"];
export const stylesheets = ["_app/immutable/assets/2.CQ7chR2Y.css"];
export const fonts = [];
