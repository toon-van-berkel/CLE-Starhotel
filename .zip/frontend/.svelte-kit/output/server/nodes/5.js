

export const index = 5;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/register/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/5.DCxEigNd.js","_app/immutable/chunks/DsnmJJEf.js","_app/immutable/chunks/69_IOA4Y.js","_app/immutable/chunks/DIeogL5L.js","_app/immutable/chunks/BEX6EZJS.js","_app/immutable/chunks/mb3lfQoK.js","_app/immutable/chunks/Co-k0xhD.js","_app/immutable/chunks/BvR5KVtc.js","_app/immutable/chunks/DsPEBdrT.js","_app/immutable/chunks/DwzC-bs9.js","_app/immutable/chunks/EprVy5qV.js","_app/immutable/chunks/h_ZGpRV-.js","_app/immutable/chunks/CfgsdJGj.js","_app/immutable/chunks/VPrQAXsl.js"];
export const stylesheets = ["_app/immutable/assets/5.DtyWFwRv.css"];
export const fonts = [];
