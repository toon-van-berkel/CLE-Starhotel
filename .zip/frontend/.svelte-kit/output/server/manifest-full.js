export const manifest = (() => {
function __memo(fn) {
	let value;
	return () => value ??= (value = fn());
}

return {
	appDir: "_app",
	appPath: "_app",
	assets: new Set(["robots.txt"]),
	mimeTypes: {".txt":"text/plain"},
	_: {
		client: {start:"_app/immutable/entry/start.DUBpUWLd.js",app:"_app/immutable/entry/app.DxIaNAbv.js",imports:["_app/immutable/entry/start.DUBpUWLd.js","_app/immutable/chunks/EprVy5qV.js","_app/immutable/chunks/BEX6EZJS.js","_app/immutable/chunks/DIeogL5L.js","_app/immutable/chunks/h_ZGpRV-.js","_app/immutable/chunks/CfgsdJGj.js","_app/immutable/entry/app.DxIaNAbv.js","_app/immutable/chunks/BEX6EZJS.js","_app/immutable/chunks/DIeogL5L.js","_app/immutable/chunks/mb3lfQoK.js","_app/immutable/chunks/Co-k0xhD.js","_app/immutable/chunks/DsnmJJEf.js","_app/immutable/chunks/CfgsdJGj.js","_app/immutable/chunks/BvR5KVtc.js","_app/immutable/chunks/CIxPz0Am.js","_app/immutable/chunks/h_ZGpRV-.js"],stylesheets:[],fonts:[],uses_env_dynamic_public:false},
		nodes: [
			__memo(() => import('./nodes/0.js')),
			__memo(() => import('./nodes/1.js')),
			__memo(() => import('./nodes/2.js')),
			__memo(() => import('./nodes/3.js')),
			__memo(() => import('./nodes/4.js')),
			__memo(() => import('./nodes/5.js'))
		],
		remotes: {
			
		},
		routes: [
			{
				id: "/",
				pattern: /^\/$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 2 },
				endpoint: null
			},
			{
				id: "/login",
				pattern: /^\/login\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 3 },
				endpoint: null
			},
			{
				id: "/profile",
				pattern: /^\/profile\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 4 },
				endpoint: null
			},
			{
				id: "/register",
				pattern: /^\/register\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 5 },
				endpoint: null
			}
		],
		prerendered_routes: new Set([]),
		matchers: async () => {
			
			return {  };
		},
		server_assets: {}
	}
}
})();
