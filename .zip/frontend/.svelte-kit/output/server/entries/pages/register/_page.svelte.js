import { h as head, a as attr } from "../../../chunks/index2.js";
import "@sveltejs/kit/internal";
import "../../../chunks/exports.js";
import "../../../chunks/utils.js";
import "@sveltejs/kit/internal/server";
import "../../../chunks/state.svelte.js";
import { $ as escape_html } from "../../../chunks/context.js";
function _page($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let first_name = "";
    let last_name = "";
    let email = "";
    let phone = "";
    let password = "";
    let password2 = "";
    let loading = false;
    head("52fghe", $$renderer2, ($$renderer3) => {
      $$renderer3.title(($$renderer4) => {
        $$renderer4.push(`<title>Register</title>`);
      });
    });
    $$renderer2.push(`<div class="wrap svelte-52fghe"><h1 class="svelte-52fghe">Create account</h1> <p class="sub svelte-52fghe">Register to access the platform.</p> <form class="card svelte-52fghe"><div class="row svelte-52fghe"><div class="field svelte-52fghe"><label for="first" class="svelte-52fghe">First name</label> <input id="first"${attr("value", first_name)} autocomplete="given-name" required class="svelte-52fghe"/></div> <div class="field svelte-52fghe"><label for="last" class="svelte-52fghe">Last name</label> <input id="last"${attr("value", last_name)} autocomplete="family-name" required class="svelte-52fghe"/></div></div> <div class="field svelte-52fghe"><label for="email" class="svelte-52fghe">Email</label> <input id="email" type="email"${attr("value", email)} autocomplete="email" required class="svelte-52fghe"/></div> <div class="field svelte-52fghe"><label for="phone" class="svelte-52fghe">Phone (optional)</label> <input id="phone"${attr("value", phone)} autocomplete="tel" class="svelte-52fghe"/></div> <div class="row svelte-52fghe"><div class="field svelte-52fghe"><label for="pw" class="svelte-52fghe">Password</label> <input id="pw" type="password"${attr("value", password)} autocomplete="new-password" required class="svelte-52fghe"/> <small class="svelte-52fghe">At least 8 characters.</small></div> <div class="field svelte-52fghe"><label for="pw2" class="svelte-52fghe">Repeat password</label> <input id="pw2" type="password"${attr("value", password2)} autocomplete="new-password" required class="svelte-52fghe"/></div></div> `);
    {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]--> `);
    {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]--> <button${attr("disabled", loading, true)} class="svelte-52fghe">${escape_html("Create account")}</button> <p class="foot svelte-52fghe">Already have an account? <a href="/login" class="svelte-52fghe">Login</a></p></form></div>`);
  });
}
export {
  _page as default
};
