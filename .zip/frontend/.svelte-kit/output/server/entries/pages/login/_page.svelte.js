import "clsx";
function _page($$renderer) {
  $$renderer.push(`<h1>Login</h1>`);
}
export {
  _page as default
};
