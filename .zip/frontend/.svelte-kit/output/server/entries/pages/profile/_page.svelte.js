import "clsx";
function _page($$renderer) {
}
export {
  _page as default
};
