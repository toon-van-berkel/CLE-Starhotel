import"../chunks/DsnmJJEf.js";import"../chunks/69_IOA4Y.js";import{f as a,a as p}from"../chunks/Co-k0xhD.js";var t=a("<h1>Login</h1>");function e(o){var r=t();p(o,r)}export{e as component};
