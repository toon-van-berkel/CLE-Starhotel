
// this file is generated — do not edit it


declare module "svelte/elements" {
	export interface HTMLAttributes<T> {
		'data-sveltekit-keepfocus'?: true | '' | 'off' | undefined | null;
		'data-sveltekit-noscroll'?: true | '' | 'off' | undefined | null;
		'data-sveltekit-preload-code'?:
			| true
			| ''
			| 'eager'
			| 'viewport'
			| 'hover'
			| 'tap'
			| 'off'
			| undefined
			| null;
		'data-sveltekit-preload-data'?: true | '' | 'hover' | 'tap' | 'off' | undefined | null;
		'data-sveltekit-reload'?: true | '' | 'off' | undefined | null;
		'data-sveltekit-replacestate'?: true | '' | 'off' | undefined | null;
	}
}

export {};


declare module "$app/types" {
	export interface AppTypes {
		RouteId(): "/(logged-out)" | "/(logged-in)" | "/(admin-panel)" | "/" | "/(admin-panel)/admin" | "/details" | "/(logged-out)/login" | "/(logged-in)/profile" | "/(logged-out)/register" | "/reservation-confirmation" | "/rooms" | "/rooms/room-[id]" | "/test/(auth)" | "/test" | "/test/contact" | "/test/contact/post" | "/test/contact/[id]" | "/test/rooms" | "/test/rooms/[id]" | "/toon";
		RouteParams(): {
			"/rooms/room-[id]": { id: string };
			"/test/contact/[id]": { id: string };
			"/test/rooms/[id]": { id: string }
		};
		LayoutParams(): {
			"/(logged-out)": Record<string, never>;
			"/(logged-in)": Record<string, never>;
			"/(admin-panel)": Record<string, never>;
			"/": { id?: string };
			"/(admin-panel)/admin": Record<string, never>;
			"/details": Record<string, never>;
			"/(logged-out)/login": Record<string, never>;
			"/(logged-in)/profile": Record<string, never>;
			"/(logged-out)/register": Record<string, never>;
			"/reservation-confirmation": Record<string, never>;
			"/rooms": { id?: string };
			"/rooms/room-[id]": { id: string };
			"/test/(auth)": Record<string, never>;
			"/test": { id?: string };
			"/test/contact": { id?: string };
			"/test/contact/post": Record<string, never>;
			"/test/contact/[id]": { id: string };
			"/test/rooms": { id?: string };
			"/test/rooms/[id]": { id: string };
			"/toon": Record<string, never>
		};
		Pathname(): "/" | "/admin" | "/admin/" | "/details" | "/details/" | "/login" | "/login/" | "/profile" | "/profile/" | "/register" | "/register/" | "/reservation-confirmation" | "/reservation-confirmation/" | "/rooms" | "/rooms/" | `/rooms/room-[id]` & {} | `/rooms/room-[id]/` & {} | "/test" | "/test/" | "/test/contact" | "/test/contact/" | "/test/contact/post" | "/test/contact/post/" | `/test/contact/${string}` & {} | `/test/contact/${string}/` & {} | "/test/rooms" | "/test/rooms/" | `/test/rooms/${string}` & {} | `/test/rooms/${string}/` & {} | "/toon" | "/toon/";
		ResolvedPathname(): `${"" | `/${string}`}${ReturnType<AppTypes['Pathname']>}`;
		Asset(): "/Hotel-Kamer.png" | "/Hotel-Kamer2.png" | "/Hotel-Kamer3.png" | "/robots.txt" | string & {};
	}
}