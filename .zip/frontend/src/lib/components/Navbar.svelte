<nav>
    <ul class="nav-ul">
        <div class="flex">
            <li><a class="bg-primary :hover" href="/">home</a></li>
            
        </div>
        <div class="flex">
            <li><a href="/details">Details</a></li>
            <li><a href="/rooms">Rooms</a></li>
            <li><a href="/about">About</a></li>
        </div>
    </ul>

    <hr>
</nav>

