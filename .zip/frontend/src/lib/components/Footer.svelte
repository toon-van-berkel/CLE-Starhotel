<hr />

<footer>
    <p class="lightgraytext">© 2026 Starhotel. All rights reserved.</p>
</footer>