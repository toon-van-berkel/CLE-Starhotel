// export type {User, RegisterPayload} from '$lib/api/types/user';
// export type {AuthState} from '$lib/api/types/auth';
// export type {Room} from '$lib/api/types/room';