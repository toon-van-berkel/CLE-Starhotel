export type reservationDetails = {
    room_id: number;
    booked_from: string;
    booked_till: string;
    totalPeople: number;
}

