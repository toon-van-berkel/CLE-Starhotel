<h1>Rooms</h1>
<h2>Get all rooms</h2>
<a href="/details">Details</a>
<ul>
    <li><a href="/test/rooms">Test rooms</a></li>
    <li><a href="/test/contact">Test contacts</a></li>
</ul>