import { apiCall } from '$lib/api/client/__index__';

export const load = async ({ fetch, params }) => {
    const contactData = await apiCall('contact', fetch, { id: Number(params.id) });
    return { contactData };
};
