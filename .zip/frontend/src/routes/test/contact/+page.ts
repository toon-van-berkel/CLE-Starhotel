import { apiCall } from '$lib/api/client/__index__';

export const load = async ({ fetch }) => {
    const contactsData = await apiCall('contacts', fetch);
    return { contactsData };
};
